# Classification-of-plant-seed
This project focuses on classifying the quality of plant seeds using machine learning techniques. The goal is to automatically determine whether a seed is healthy, unhealthy, good-quality, or poor-quality based on measurable features.
